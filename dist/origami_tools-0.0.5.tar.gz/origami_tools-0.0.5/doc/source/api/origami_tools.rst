origami\_tools package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   origami_tools.Geometry
   origami_tools.LaserParams
   origami_tools.Origamis
   origami_tools.Pattern
   origami_tools.Utils

Module contents
---------------

.. automodule:: origami_tools
   :members:
   :show-inheritance:
   :undoc-members:
