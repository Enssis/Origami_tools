origami\_tools.Geometry package
===============================

Submodules
----------

origami\_tools.Geometry.line module
-----------------------------------

.. automodule:: origami_tools.Geometry.line
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Geometry.plane module
------------------------------------

.. automodule:: origami_tools.Geometry.plane
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Geometry.repere module
-------------------------------------

.. automodule:: origami_tools.Geometry.repere
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Geometry.shape module
------------------------------------

.. automodule:: origami_tools.Geometry.shape
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Geometry.surface module
--------------------------------------

.. automodule:: origami_tools.Geometry.surface
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Geometry.vector module
-------------------------------------

.. automodule:: origami_tools.Geometry.vector
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Geometry.volume module
-------------------------------------

.. automodule:: origami_tools.Geometry.volume
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: origami_tools.Geometry
   :members:
   :show-inheritance:
   :undoc-members:
