origami\_tools.Origamis package
===============================

Submodules
----------

origami\_tools.Origamis.kresling module
---------------------------------------

.. automodule:: origami_tools.Origamis.kresling
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: origami_tools.Origamis
   :members:
   :show-inheritance:
   :undoc-members:
