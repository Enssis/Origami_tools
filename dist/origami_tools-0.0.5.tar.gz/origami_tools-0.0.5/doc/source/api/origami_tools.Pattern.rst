origami\_tools.Pattern package
==============================

Submodules
----------

origami\_tools.Pattern.drawn\_shapes module
-------------------------------------------

.. automodule:: origami_tools.Pattern.drawn_shapes
   :members:
   :show-inheritance:
   :undoc-members:

origami\_tools.Pattern.pattern module
-------------------------------------

.. automodule:: origami_tools.Pattern.pattern
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: origami_tools.Pattern
   :members:
   :show-inheritance:
   :undoc-members:
