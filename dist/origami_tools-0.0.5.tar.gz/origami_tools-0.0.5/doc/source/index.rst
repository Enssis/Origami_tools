.. origami_tools documentation master file, created by
   sphinx-quickstart on Thu Oct 30 16:04:49 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to origami_tools's Documentation!  
=====================================  

.. toctree::  
   :maxdepth: 2  
   :caption: Contents:  

   api/modules
   quick_start/index

Indices and tables  
==================  

* :ref:`genindex`  
* :ref:`modindex`  
* :ref:`search`  
